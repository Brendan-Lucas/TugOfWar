/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x8ef4fb42 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif




extern void simprims_ver_m_00000000000648012491_3151998091_3881379368_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_3881379368", "isim/ToW_tb_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_3881379368.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_1093545372_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_1093545372", "isim/ToW_tb_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_1093545372.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_1892038401_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_1892038401", "isim/ToW_tb_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_1892038401.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_3919760131_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_3919760131", "isim/ToW_tb_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_3919760131.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_0738588045_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_0738588045", "isim/ToW_tb_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_0738588045.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_0553237387_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_0553237387", "isim/ToW_tb_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_0553237387.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_1039957220_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_1039957220", "isim/ToW_tb_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_1039957220.didat");
}
